# BLACKICE CLIPS — Starter Website

This is a no-build, beginner-friendly prototype of the BlackIce Clips video editing platform.

## Run it

1. Unzip the folder.
2. Double-click `index.html`.
3. The site runs in your browser.

## What is already included

- BlackIce Clips branding and black/white/cyan theme
- Dashboard / home page
- Project library
- Templates
- Stock assets
- Pricing plans
- Transaction history
- Settings
- Browser editor UI
- Timeline with video/text/audio tracks
- Tool sidebar
- Preview area
- Mock upgrade and micro-purchase flows

## Important

The payment buttons are DEMOS. They do NOT process real payments.

For real subscriptions and microtransactions, the next production step should be:
- User authentication
- Database for projects/users
- Cloud video storage
- Video processing/rendering backend
- Stripe Checkout + webhooks
- Subscription entitlement checks
- Secure file upload limits
- Real export queue

The current editor is a UI prototype. It does not yet render uploaded video files.
