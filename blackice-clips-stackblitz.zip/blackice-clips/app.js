const projects = [
  {name:"Game Clip Edit",time:"Edited 2 hours ago",duration:"03:24",style:""},
  {name:"Mountain Montage",time:"Edited yesterday",duration:"07:18",style:"alt"},
  {name:"Vlog Edit",time:"Edited 2 days ago",duration:"00:42",style:"purple"},
  {name:"Tutorial",time:"Edited 2 days ago",duration:"12:16",style:"alt"}
];
const transactions = [
  {date:"Sep 25, 2026",desc:"Pro Plan (Monthly)",amount:"$14.99",status:"Completed"},
  {date:"Sep 10, 2026",desc:"Ice Effects Pack",amount:"$2.99",status:"Completed"},
  {date:"Aug 29, 2026",desc:"Plus Plan (Monthly)",amount:"$7.99",status:"Completed"}
];

function renderProjects(){
  const html=projects.map((p,i)=>`<div class="project-card" onclick="openEditor('${p.name}')"><div class="project-thumb ${p.style}">BLACKICE</div><div class="project-info"><b>${p.name}</b><span>${p.time} • ${p.duration}</span></div></div>`).join("");
  document.getElementById("recent-projects").innerHTML=html;
  document.getElementById("all-projects").innerHTML=html + `<div class="project-card" onclick="newProject()"><div class="project-thumb">＋</div><div class="project-info"><b>New Project</b><span>Start editing</span></div></div>`;
}
function renderTransactions(){
  document.getElementById("transactions-body").innerHTML=transactions.map(t=>`<tr><td>${t.date}</td><td>${t.desc}</td><td>${t.amount}</td><td><span class="status">${t.status}</span></td></tr>`).join("");
}
function showPage(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active-page"));
  const target=document.getElementById("page-"+page);
  if(target) target.classList.add("active-page");
  document.querySelectorAll(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.page===page));
  const titles={home:"Home",projects:"My Projects",templates:"Templates",assets:"Stock Assets",pricing:"Pricing",transactions:"Transactions",settings:"Settings",editor:"Editor"};
  document.getElementById("page-title").textContent=titles[page]||"Home";
}
function openEditor(name="Untitled Project"){document.getElementById("editor-name").textContent=name;showPage("editor")}
function newProject(name="Untitled Project"){projects.unshift({name,time:"Just now",duration:"00:00",style:""});renderProjects();openEditor(name)}
function toolSelect(el){document.querySelectorAll(".tool").forEach(x=>x.classList.remove("active"));el.classList.add("active");toast(el.innerText+" tool selected")}
function fakeUpload(){toast("Demo upload opened — connect cloud storage/backend next")}
function exportProject(){modal("Export Project","Your editor is ready for export. In the production version, this button will render the timeline on the server and return an MP4 download.")}
function checkout(plan,price){transactions.unshift({date:new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}),desc:`${plan} Plan (Monthly)`,amount:`$${price.toFixed(2)}`,status:"Completed"});renderTransactions();modal(`Upgrade to ${plan}`,`Demo checkout: $${price.toFixed(2)}/month. Real card payments should be connected through Stripe Checkout before launch.`)}
function buyAssetPack(){transactions.unshift({date:"Sep 30, 2026",desc:"Ice Effects Pack",amount:"$2.99",status:"Completed"});renderTransactions();modal("Ice Effects Pack","Demo purchase added to your transaction history. Real micro-payments can use Stripe Checkout or another payment provider.")}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");clearTimeout(window._toast);window._toast=setTimeout(()=>t.classList.remove("show"),2200)}
function modal(title,text){document.getElementById("modal-title").textContent=title;document.getElementById("modal-text").textContent=text;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
renderProjects();renderTransactions();
